public class Frac_add_sub {
    public String fractionAddition(String expression) {
        int numerator = 0;
        int denominator = 1;

        int i = 0, n = expression.length();
        while (i < n) {
            // Handle sign
            int sign = 1;
            if (expression.charAt(i) == '+' || expression.charAt(i) == '-') {
                if (expression.charAt(i) == '-') sign = -1;
                i++;
            }

            // Parse numerator
            int num = 0;
            while (i < n && Character.isDigit(expression.charAt(i))) {
                num = num * 10 + (expression.charAt(i++) - '0');
            }

            // Skip '/'
            i++; 

            // Parse denominator
            int den = 0;
            while (i < n && Character.isDigit(expression.charAt(i))) {
                den = den * 10 + (expression.charAt(i++) - '0');
            }

            // Combine current fraction with the result so far
            numerator = numerator * den + sign * num * denominator;
            denominator *= den;

            // Reduce the fraction
            int gcd = gcd(Math.abs(numerator), denominator);
            numerator /= gcd;
            denominator /= gcd;
        }

        return numerator + "/" + denominator;
    }

    // Euclidean algorithm to find GCD
    private int gcd(int a, int b) {
        while (b != 0) {
            int t = b;
            b = a % b;
            a = t;
        }
        return a;
    }
}

public class Sqrt_x{
    public int mySqrt(int x) {
        if (x == 0) {
            return 0;
        }
        int low = 1;
        int high = x;
        while (low <= high) {
            int mid = low + (high - low) / 2;
            long midSquared = (long) mid * mid;
            if (midSquared == x) {
                return mid;
            } else if (midSquared < x) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return high;
    }

    public static void main(String[] args) {
        Sqrt_x solution = new Sqrt_x();
        
        // Test cases
        int[] testCases = {4, 8, 0, 1, 2147395599, 25, 2};
        
        for (int x : testCases) {
            System.out.println("sqrt(" + x + ") = " + solution.mySqrt(x));
        }
    }
}
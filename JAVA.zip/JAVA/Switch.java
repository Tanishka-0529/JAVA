class Switch{
    public static void main(String[] args)
    {
        int num = 40;
        switch (num) {
        case 20:
            System.out.println("It is 20");
            break;
        case 10:
            System.out.println("It is 10");
            break;
        case 15:
            System.out.println("It is 15");
            break;
        case 25:
            System.out.println("It is 25");
            break;
        default:
            System.out.println("Not present");
        }
    }
}

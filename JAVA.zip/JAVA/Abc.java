public class Abc {
  private class RunnableImpl implements Runnable {
      @Override
      public void run() {
          System.out.println(Thread.currentThread().getName()
                           + ", executing run() method!");
      }
  }

  public static void main(String[] args) {
      System.out.println("Main thread is: " + Thread.currentThread().getName());

      Abc abc = new Abc(); // create an instance of the outer class
      Thread t1 = new Thread(abc.new RunnableImpl());
      t1.start();
  }
}

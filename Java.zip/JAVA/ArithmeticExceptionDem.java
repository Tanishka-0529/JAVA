class ArithmeticExceptionDemo {
    public static void main(String[] args) {
        try {
            // This will throw an ArithmeticException
            int a = 10 / 0;
        } 
        // Handling the exception
        catch (ArithmeticException e) {
            System.out.println("Exception caught: " + e);
        }

        // This line will execute whether an exception occurs or not
        System.out.println("I will always execute");
    }
}

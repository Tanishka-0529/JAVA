 
    // the working of if-else statement

    public class If {
        public static void main(String args[])
        {
            int i = 20;
    
            if (i < 30)
                System.out.println("i is smaller than 30");
            else
                System.out.println("i is greater than 30");
        }
    }
    
    


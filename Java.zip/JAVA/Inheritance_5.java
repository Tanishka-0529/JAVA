
class Animal {
 
    public void move() {
        System.out.println("The animal moves.");
    }
}

class Cheetah extends Animal {
    @Override
    public void move() {
        System.out.println("The cheetah runs swiftly.");
    }
}

public class Inheritance_5 {
    public static void main(String[] args) {
        Animal genericAnimal = new Animal();
        Animal fastCheetah = new Cheetah();

        System.out.println("Animal movement:");
        genericAnimal.move();    

        System.out.println("Cheetah movement:");
        fastCheetah.move();     
    }
}
